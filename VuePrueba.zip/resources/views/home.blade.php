@extends('layouts.app')

@section('content')
<div class="container">
    <my-component-pensamientos> </my-component-pensamientos>
</div>
@endsection
